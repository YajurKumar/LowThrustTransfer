%--------------------------------------------------------------------------
% MCW_plot.m
% MCW plotting function
%--------------------------------------------------------------------------
% MCW_plot(t,X,U,f,p)
% t: time
% X: state
% U: control
% f: objective function value
% p: parameter structure
%--------------------------------------------------------------------------
% Copyright Yajur Kumar, 2017. All rights reserved.
% Date : March 15, 2017
%
%--------------------------------------------------------------------------
function MCW_plot(t,X,U,f,p)

% interpolate the solution with the specified polynomials
interpN = 2000; % number of linearly spaced interpolation points
for i = 1:length(p.Narray)
    % interpolate based on method
    tarray1{i} = linspace(p.t0(i),p.tf(i),interpN);
    interpX1{1,i} = LagrangeInter(p.t{i}',X(p.cumN(i)+1:p.cumN(i+1),1)',tarray1{i});
    interpX1{2,i} = LagrangeInter(p.t{i}',X(p.cumN(i)+1:p.cumN(i+1),2)',tarray1{i});
    interpX1{3,i} = LagrangeInter(p.t{i}',X(p.cumN(i)+1:p.cumN(i+1),3)',tarray1{i});
    interpX1{4,i} = LagrangeInter(p.t{i}',X(p.cumN(i)+1:p.cumN(i+1),4)',tarray1{i});
    interpX1{5,i} = LagrangeInter(p.t{i}',X(p.cumN(i)+1:p.cumN(i+1),5)',tarray1{i});
    interpX1{6,i} = LagrangeInter(p.t{i}',X(p.cumN(i)+1:p.cumN(i+1),6)',tarray1{i});
    
    interpU1{1,i} = LagrangeInter(p.t{i}',U(p.cumN(i)+1:p.cumN(i+1),1)',tarray1{i});
    interpU1{2,i} = LagrangeInter(p.t{i}',U(p.cumN(i)+1:p.cumN(i+1),2)',tarray1{i});
    interpU1{3,i} = LagrangeInter(p.t{i}',U(p.cumN(i)+1:p.cumN(i+1),3)',tarray1{i});

end
% create column vectors
tarray = cell2mat(tarray1)';
interpX = cell2mat(interpX1)';
interpU = cell2mat(interpU1)';

figI = 0; % initial figure index
font1 = 18; % font size parameter
font2 = 12;

%--- plot states and control
figI = figI + 1;
figure(figI); clf(figI);

xc = [0.7 0.7 0.7];
vc = [0 0 0];
uc = [0.8500 0.3250 0.0980];

[hAinterp,hd1interp,hd2interp] = plotyy(tarray,interpX,tarray,interpU); hold on
plot([0 1], [10 10],'linewidth',2,'color',uc); hold on
[hA,hd1,hd2] = plotyy(t,X,t,U); hold on

set(hAinterp(1),'YTick',[])
set(hAinterp(2),'YTick',[])
set(hA(1),'YTick',[])
set(hA(2),'YTick',[])

% interp style
set(hd1interp(1),'linewidth',2,'color',xc);
set(hd1interp(2),'linewidth',2,'color',vc);
set(hd2interp(1),'linewidth',2,'color',uc);

% node style
set(hd1(1),'linestyle','none','Marker','o','linewidth',2,'color',xc);
set(hd1(2),'linestyle','none','Marker','o','linewidth',2,'color',vc);
set(hd2(1),'linestyle','none','Marker','o','linewidth',2,'color',uc);

% y labels
ylabel(hAinterp(1),'$x$ [m], $v$ [m/s]','interpreter','latex','fontsize',font1) % left y-axis
ylabel(hAinterp(2),'$u$ [m/s$^2$]','interpreter','latex','fontsize',font1,'color',uc) % right y-axis

% 
set(hAinterp(1),'ylim',[-1 1])
set(hAinterp(2),'ylim',[-7 1])
set(hA(1),'ylim',[-1 1])
set(hA(2),'ylim',[-7 1])



[hx,hy] = format_ticks_v2(hAinterp(1),[],{' '},[],...
    0,[],[],[],0.02);
set(hy,'fontsize',font2)
delete(hx)
[hx,hy] = format_ticks_v2(hA(1),[],{'$-1$','$-0.5$','$0$','$0.5$','$1$'},[],...
    -1:0.5:1,[],[],[],0.02);
set(hy,'fontsize',font2)
delete(hx)


[hx,hy] = format_ticks_v2(hAinterp(2),[],{' '},[],...
    0,[],[],[],0.02);
set(hy,'fontsize',font2)
delete(hx)
% [hx,hy] = format_ticks_v2(hA(2),[],{'$-6$','$-4$','$-2$','$0$'},[],...
%     -6:2:0,[],[],[],0.0);
% set(hy,'fontsize',font2)
% delete(hx)

%
set(hA(1),'ycolor',vc);
set(hA(2),'ycolor',uc);


ylabh = get(hAinterp(1),'YLabel');
set(ylabh,'Position',get(ylabh,'Position') - [0.05 0 0])

[hx,hy] = format_ticks_v2(hAinterp(2),{' '},[],0,[],[],[],[],0.005);
[hx,hy] = format_ticks_v2(hA(1),{' '},[],0,[],[],[],[],0.005);
[hx,hy] = format_ticks_v2(hA(2),{' '},[],0,[],[],[],[],0.005);

[hx,hy] = format_ticks_v2(hAinterp(1),{'$0$','$0.25$','$0.5$','$0.75$','$1$'},[],...
    0:0.25:1,[],[],[],[],0.005);
set(hx,'fontsize',font2)


xlabel('$t$ (s)','interpreter','latex','fontsize',font1);
xlabh = get(gca,'XLabel');
set(xlabh,'Position',get(xlabh,'Position') - [0 .06 0])

% legend
hL = legend('$x_{\mathrm{interp}}$','$v_{\mathrm{interp}}$',...
    '$u_{\mathrm{interp}}$',['$x_{\mathrm{',p.method,'}}$'],...
    ['$v_{\mathrm{',p.method,'}}$'],['$u_{\mathrm{',p.method,'}}$']);
set(hL,'orientation','horizontal','interpreter','latex',...
    'Position',[0.03,0.93,0.95,0.08],'box','off')

% set(hL,'PlotBoxAspectRatioMode','manual');
% set(hL,'PlotBoxAspectRatio',[18 1 1]);

ylabh = get(hAinterp(2),'YLabel');
set(ylabh,'Position',get(ylabh,'Position') + [0.04 0 0])
set(hAinterp(2),'YTick',-6:2:0,'ycolor',uc)


annotation('textbox',[0.90 0.745 0.1 0.1],'String','$0$','interpreter','latex',...
    'color',uc,'fontsize',font2,'edgecolor','none')

annotation('textbox',[0.90 0.545 0.1 0.1],'String','$-2$','interpreter','latex',...
    'color',uc,'fontsize',font2,'edgecolor','none')

annotation('textbox',[0.90 0.345 0.1 0.1],'String','$-4$','interpreter','latex',...
    'color',uc,'fontsize',font2,'edgecolor','none')

annotation('textbox',[0.90 0.145 0.1 0.1],'String','$-6$','interpreter','latex',...
    'color',uc,'fontsize',font2,'edgecolor','none')

%% --- plot error between actual solution
figI = figI + 1;
figure(figI); clf(figI);
% semilogy([10 11],[1 1],'linewidth',2,'color',xc); hold on
% semilogy([10 11],[1 1],'linewidth',2,'color',vc); hold on
% semilogy([10 11],[1 1],'linewidth',2,'color',uc); hold on
% get actual solution values
[sMat,uMat] = MCW_solution(tarray,p.l);
% plot position error
error = abs(interpX(:,1)-sMat(:,1));
results.maxx = max(error);
plot(tarray,log10(error),'color',xc,'linewidth',2); hold on
% plot velocity error
error = abs(interpX(:,2)-sMat(:,2));
results.maxv = max(error);
plot(tarray,log10(error),'color',vc,'linewidth',2); hold on
% plot control error
error = abs(interpU-uMat);
results.maxu = max(error);
plot(tarray,log10(error),'color',uc,'linewidth',2); hold on

% label and other plotting stuff
ylabel('absolute error','interpreter','latex','fontsize',font1);

set(hL,'interpreter','latex','fontsize',font1-6);
xlim([p.Tarray(1) p.Tarray(end)]); ylim([-18 0]);

set(gca,'YTickLabel',[],'YTick',[-15,-10,-5,0])

[hx,hy] = format_ticks_v2(gca,[],{'$10^{-15}$','$10^{-10}$','$10^{-5}$','$10^{0}$'},[],...
    [-15,-10,-5,0],[],[],[],0.01);
set(hy,'fontsize',font2)
delete(hx)

[hx,hy] = format_ticks_v2(gca,{'$0$','$0.25$','$0.5$','$0.75$','$1$'},[],...
    0:0.25:1,[],[],[],[],0);
set(hx,'fontsize',font2)


xlabel('$t$ (s)','interpreter','latex','fontsize',font1);
xlabh = get(gca,'XLabel');
set(xlabh,'Position',get(xlabh,'Position') - [0 .55 0])


ylabh = get(gca,'YLabel');
set(ylabh,'Position',get(ylabh,'Position') - [0.09 0 0])

% legend
hL = legend('error $x$','error $v$','error $u$');
set(hL,'orientation','horizontal','interpreter','latex',...
    'Position',[0.03,0.93,0.95,0.08],'box','off')

% set(hL,'PlotBoxAspectRatioMode','manual');
% set(hL,'PlotBoxAspectRatio',[10 1 1]);

% results 
results.Nt = length(U);
results.NI = length(p.Narray);
results.f = f;
results.ferror = abs(f - 4/(9*p.l));

format shortE
disp(results)

% path = msavename(mfilename('fullpath'),'Saved_Data');
% save([path,'BDsol-',p.method,'-Nt_',num2str(results.Nt),'-NI_',num2str(results.NI),...
%     '-results','.mat'],'results')

% save2pdf([path,'BDsol-',p.method,'-Nt_',num2str(results.Nt),'-NI_',num2str(results.NI),'-sol.pdf'],1,600)
% save2pdf([path,'BDsol-',p.method,'-Nt_',num2str(results.Nt),'-NI_',num2str(results.NI),'-error.pdf'],2,600)

end