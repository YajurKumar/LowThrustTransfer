%--------------------------------------------------------------------------
% Copyright Yajur Kumar, 2017. All rights reserved.
% Date : March 13, 2017
%--------------------------------------------------------------------------
% main.m
% Main Program for Calculating Optimal Low-Thrust Motion using
% Legendre-Gauss-Lobatto Pseudospectral Method
% -Main script for solving optimal control problems using 
% multiple-interval pseudospectral methods
% -Define the mesh and method, then solves, then plots solution
% -Note that case 0 can be changed by the user
% -Other cases are based on the technical report of the same name
%--------------------------------------------------------------------------

clc;
clear all;
close all;
% study number, see technical report
study = 2; % 0 indicates user defined mesh

% pseudospectral method
p.method = 'LGL'; % either LGL or CGL

% scale problem
p.scale = 1; % 0: no, 1:yes

% Starting and Ending Time
t0 = 0;
tf = 2000;

% switch statement for case studies
switch study
    case 0
        %--- user defined mesh ---%
        p.Tarray = linspace(t0,tf,3); % segment boundaries
        p.Narray = 10*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment (same size as p.Tarray)
        %--- user defined mesh ---%
    case 1
        p.Tarray = [t0,tf]; % segment boundaries
        p.Narray = 4+1; % number of nodes per segment (same size as p.Tarray)
    case 2
        p.Tarray = [t0,tf]; % segment boundaries
        p.Narray = 9+1; % number of nodes per segment (same size as p.Tarray)
    case 3
        p.Tarray = [t0,tf]; % segment boundaries
        p.Narray = 19+1; % number of nodes per segment (same size as p.Tarray)
    case 4
        p.Tarray = linspace(t0,tf,3); % segment boundaries
        p.Narray = 3*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment (same size as p.Tarray)
    case 5
        p.Tarray = linspace(t0,tf,3); % segment boundaries
        p.Narray = 5*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment (same size as p.Tarray)
    case 6
        p.Tarray = linspace(t0,tf,3); % segment boundaries
        p.Narray = 9*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment (same size as p.Tarray)
    case 7
        p.Tarray = linspace(t0,tf,6); % segment boundaries
        p.Narray = 3*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment (same size as p.Tarray)
    case 8
        p.Tarray = linspace(t0,tf,6); % segment boundaries
        p.Narray = 5*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment (same size as p.Tarray)
    case 9
        p.Tarray = linspace(t0,tf,6); % segment boundaries
        p.Narray = 9*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment (same size as p.Tarray)
    case 10
        p.Tarray = linspace(t0,tf,11); % segment boundaries
        p.Narray = 3*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment (same size as p.Tarray)
    case 11
        p.Tarray = linspace(t0,tf,11); % segment boundaries
        p.Narray = 5*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment (same size as p.Tarray)
    case 12
        p.Tarray = linspace(t0,tf,11); % segment boundaries
        p.Narray = 9*ones(1,length(p.Tarray)-1)+1; % number of nodes per segment (same size as p.Tarray)
end

% solve the problem
MCW_solve(p);
